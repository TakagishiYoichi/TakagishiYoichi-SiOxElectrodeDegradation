

Num_images=3360;   % Number of images


%Data loading--------------------------------------------------
fprintf("-------------------------------------------------\n");
fprintf("loading SEM images ...\n");

XTrain=zeros(56,56,1,Num_images);
for n=1:Num_images
    if(n<10)
        filenum=strcat('000', num2str(n));
    elseif(n<100)
        filenum=strcat('00', num2str(n));
    elseif(n<1000)
        filenum=strcat('0', num2str(n));
    else
        filenum=num2str(n);
    end
    infilename=strcat('SegmentedImages\img',filenum, '.png');
    tempA=imread(infilename);
    tempA=double(tempA);

    for i=1:56
        for j=1:56
            XTrain(i,j,1,n)=tempA(i,j)/256;
        end
    end

end

XTest=zeros(56,56,1,29);
for n=1:29
    if(n<10)
        filenum=strcat('000', num2str(n));
    elseif(n<100)
        filenum=strcat('00', num2str(n));
    elseif(n<1000)
        filenum=strcat('0', num2str(n));
    else
        filenum=num2str(n);
    end
    infilename=strcat('SegmentedImages_test\img', filenum, '.png');
    tempA=imread(infilename);
    tempA=double(tempA)/256;
    
end


% 56x56の画像を1x3136の1次元ベクトルへreshapeする
OneDim_XTrain=zeros(Num_images,3136);
for n=1:Num_images
    m=1;
    for i=1:56
        for j=1:56
            OneDim_XTrain(n,m)=XTrain(i,j,n);
            m=m+1;
        end
    end
end



%% 

% 100サイクル目の画像読み込み
Xcycle100=zeros(56,56,1,352);
%m=1;
for n=1:352
    if(n<10)
        filenum=strcat('000', num2str(n));
    elseif(n<100)
        filenum=strcat('00', num2str(n));
    elseif(n<1000)
        filenum=strcat('0', num2str(n));
    else
        filenum=num2str(n);
    end
    infilename=strcat('SegmentedImagesforCycle100\img', filenum, '.png');
    tempA=imread(infilename);
    tempA=double(tempA)/256;
    
    for i=1:56
        for j=1:56
            Xcycle100(i,j,1,n)=tempA(i,j); 
        end
    end

end




% 56x56の画像を1x3136の1次元ベクトルへreshapeする
OneDim_Xcycle100=zeros(352,3136);
for n=1:352
    m=1;
    for i=1:56
        for j=1:56
            OneDim_Xcycle100(n,m)=Xcycle100(i,j,n);
            m=m+1;
        end
    end
end


figure;
pcolor(Xcycle100(:,:,1))



%% 

%PCA------------------------------------------------------------------
[coeff, score, latent, tsquared,explained,mu]=pca(OneDim_XTrain);

outscore=score;




%% PCAデータの復元
Recov_XTrain=zeros(56,56,Num_images);
N_COMP_DIM=250;
score2=score(:,1:N_COMP_DIM);
coeff2=coeff(:,1:N_COMP_DIM);
test2=score2*coeff2'+mu;

for n=1:Num_images
    m=1;
    for i=1:56
        for j=1:56
            Recov_XTrain(i,j,n)=test2(n,m);  %OneDim_Xtrain(n,m);
            m=m+1;
        end
    end
end



    %% 

CycleNum=4;
N_Recov_Image=2016:2688;          %復元する画像番号

for n=501:600  %length(N_Recov_Image)

    for mi=1:56
        for mj=1:56
            if(Recov_XTrain(mi,mj,N_Recov_Image(n))<=0.33)
                Recov_XTrain(mi,mj,N_Recov_Image(n))=0;
            elseif(Recov_XTrain(mi,mj,N_Recov_Image(n))<=0.66)
                Recov_XTrain(mi,mj,N_Recov_Image(n))=0.5;
            else
                Recov_XTrain(mi,mj,N_Recov_Image(n))=1.0;
            end
        end
    end


    %figure;
    subplot(10,10,n-500);
    fig=pcolor(Recov_XTrain(:,:,N_Recov_Image(n)));
    set(fig, 'Edgecolor', 'none');
    %colorbar;
    %pbaspect([1 1 1])
    clim([0 1]);
    axis off;
    

end

%% 

figure;

for n=1:5  %length(N_Recov_Image)
    subplot(1,5,n);
    fig=pcolor(XTrain(:,:,N_Recov_Image(n)));
    set(fig, 'Edgecolor', 'none');
    %colorbar;
    %pbaspect([1 1 1])
    clim([0 1]);
    axis off;
    

end

%% 


figure;

for n=1:5  %length(N_Recov_Image)
    subplot(1,5,n);
    fig=pcolor(Recov_XTrain(:,:,N_Recov_Image(n))-XTrain(:,:,N_Recov_Image(n)));
    set(fig, 'Edgecolor', 'none');
    %colorbar;
    %pbaspect([1 1 1])
    %clim([0 1]);
    axis off;
    

end


%% 

% PC1, PC2, PC3の３次元空間に各画像データをマップする
Num_images_forTrain=3360;
outscore2=score2;
add_array=zeros(Num_images_forTrain,1);

for n=1:Num_images_forTrain/5*1
    add_array(n,1)=1;
end
for n=Num_images_forTrain/5*1+1:Num_images_forTrain/5*2
    add_array(n,1)=2;
end
for n=Num_images_forTrain/5*2+1:Num_images_forTrain/5*3
    add_array(n,1)=3;
end
for n=Num_images_forTrain/5*3+1:Num_images_forTrain/5*4
    add_array(n,1)=4;
end
for n=Num_images_forTrain/5*4+1:Num_images_forTrain/5*5
    add_array(n,1)=5;
end
for n=Num_images_forTrain/5*5+1:Num_images
    add_array(n,1)=6;
end


outscore2=horzcat(outscore2,add_array);

figure;
scatter3(outscore2(1:Num_images_forTrain,1),outscore2(1:Num_images_forTrain,2),outscore2(1:Num_images_forTrain,3),[],outscore2(1:Num_images_forTrain,251),'filled')
colormap("jet")
xlim([-10 10])
ylim([-10 10])
zlim([-10 10])




%% 

% PC1, PC2, PC3それぞれのヒストグラム
edges=-10:10;

for n=1:3

    figure
    histogram(outscore(672*0+1:672*1,n),edges,'Normalization','probability')
    ylim([0 0.25])
    hold on
    histogram(outscore(672*4+1:672*5,n),edges,'Normalization','probability')

end



%% 
% 
% Cycle100の画像ベクトルデータにPCAを適用する
score2_cycle100=(OneDim_Xcycle100-mu)*coeff2;


figure;
%scatter3(outscore2(1:672,1),outscore2(1:672,2),outscore2(1:672,3),[],outscore2(1:672,251),'filled')
scatter3(outscore2(1:672,1),outscore2(1:672,2),outscore2(1:672,3),[],'MarkerFaceColor','b','MarkerFaceAlpha',0.3)
hold on;
scatter3(outscore2(672*4+1:672*5,1),outscore2(672*4+1:672*5,2),outscore2(672*4+1:672*5,3),[],'MarkerFaceColor','r','MarkerFaceAlpha',0.3)
scatter3(score2_cycle100(:,1),score2_cycle100(:,2),score2_cycle100(:,3),[],'MarkerEdgeColor',[0 0 0],...
              'MarkerFaceColor',[0 0 0])

xlim([-10 10])
ylim([-10 10])
zlim([-10 10])
colormap('jet')




%% 



% 各サイクル（1,2,3,4,5）の重心点をマップする
masscenter=zeros(5,N_COMP_DIM+1);

for p=1:5
    for n=Num_images/5*(p-1)+1:Num_images/5*p
        for m=1:N_COMP_DIM
            masscenter(p,m)=masscenter(p,m)+score2(n,m);
        end
    end
   masscenter(p,:)=masscenter(p,:)/(Num_images/5);
end

for p=1:5
    masscenter(p,N_COMP_DIM+1)=p;
end


% 100サイクル目の重心点を計算する
masscenter_cycle100=zeros(1,N_COMP_DIM);
for n=1:352
    for m=1:N_COMP_DIM
        masscenter_cycle100(1,m)=masscenter_cycle100(1,m)+score2_cycle100(n,m);
    end
end
masscenter_cycle100(1,:)=masscenter_cycle100(1,:)/352;



% 分散行列Σをフィッティングする
sigmapc=zeros(5,N_COMP_DIM);

for p=1:5
    for n=Num_images/5*(p-1)+1:Num_images/5*p
        for m=1:250
            sigmapc(p,m)=sigmapc(p,m)+(score2(n,m)-masscenter(p,m))*(score2(n,m)-masscenter(p,m))';
        end
    end
   sigmapc(p,:)=sigmapc(p,:)/Num_images;
end

% 100サイクル目の分散を計算する
sigmapc_cycle100=zeros(1,N_COMP_DIM);
for n=1:100 %352
    for m=1:N_COMP_DIM
        sigmapc_cycle100(1,m)=sigmapc_cycle100(1,m)+(score2_cycle100(n,m)-masscenter_cycle100(1,m))*(score2_cycle100(n,m)-masscenter_cycle100(1,m))';
    end
end
sigmapc_cycle100(1,:)=sigmapc_cycle100(1,:)/100;  %352;



% 重心（平均）点の表示
figure;
scatter3(masscenter(:,1),masscenter(:,2),masscenter(:,3),[],masscenter(:,N_COMP_DIM+1),'filled');
hold on;
scatter3(masscenter_cycle100(1,1),masscenter_cycle100(1,2),masscenter_cycle100(1,3),[],...
    'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0])
xlim([-10 10])
ylim([-10 10])
zlim([-10 10])


% 正規分布の表示
for n=1:6

    figure;
    x=linspace(-10,10,200);
    y=normpdf(x,masscenter(1,N_COMP_DIM),sqrt(sigmapc(1,n)));
    plot(x,y)
    hold on;
    for p=2:5
        y=normpdf(x,masscenter(p,n),sqrt(sigmapc(p,n)));
        plot(x,y)
    end

    ylim([0 0.6])

end



%% 

% 【全データ使用＋外挿予測】----------------------------------------------
% 各サイクル数の重心点に対してGaussianProcessを適用する

x_obs=[0;1;sqrt(2);sqrt(5);sqrt(10)];

mod_masscenter=masscenter;
mod_masscenter(1,:)=masscenter(3,:);
mod_masscenter(3,:)=masscenter(1,:);
mod_masscenter(4,:)=masscenter(5,:);
mod_masscenter(5,:)=masscenter(4,:);


% 各PC次元を時間方向に回帰する

y_pred_vector=zeros(100,N_COMP_DIM);

for n=1:N_COMP_DIM
    y_obs=mod_masscenter(:,n);        

    sigma0 = 1e-4;%0.2;
    kparams0 = [3.5e-1, 6.2e-1]; %[3.5, 6.2];
    %gprMdl1=fitrgp(x_obs, y_obs,'KernelFunction','squaredexponential',...
    %     'KernelParameters',kparams0,'Sigma',sigma0);
    gprMdl1=fitrgp(x_obs, y_obs);

    x_pred=linspace(0,10,100)';
    [y_pred,~,yint]=predict(gprMdl1,x_pred);

    y_pred_vector(:,n)=y_pred;


     %外挿の線形補間
     x_exterp=linspace(sqrt(5),sqrt(100),50)';
     y_exterp(:,n)=mod_masscenter(4,n)+(mod_masscenter(5,n)-mod_masscenter(4,n))/(sqrt(10)-sqrt(5))*(x_exterp-sqrt(5));


    % 全部表示すると大変なので、PC1-3まで時間方向に表示する
    if(n<=3)
        figure;
        scatter(x_obs,y_obs,70,'blue');
        hold on;
        plot(x_pred,y_pred,'black', 'LineWidth',1.5);
        patch([x_pred;flipud(x_pred)],[yint(:,1);flipud(yint(:,2))],'k','FaceAlpha',0.1);
        scatter(sqrt(100),masscenter_cycle100(1,n),'black','filled');
        plot(x_exterp,y_exterp(:,n),'LineWidth',1.5)
        ylim([-8 8])
    end

end



%% 

% 標準偏差の各PC次元を時間方向に回帰する
% ^^^^^^^^
y_sigma_vector_ext=zeros(100,N_COMP_DIM);

for n=1:N_COMP_DIM
    y_obs_ext=sigmapc(:,n);

    sigma0 = 1e-4;%0.2;
    kparams0 = [3.5e-1, 6.2e-1]; %[3.5, 6.2];
    %gprMdl1=fitrgp(x_obs, y_obs,'KernelFunction','squaredexponential',...
    %     'KernelParameters',kparams0,'Sigma',sigma0);
    gprMdl1=fitrgp(x_obs, y_obs_ext);

    x_pred_ext=linspace(0,10,100)';
    [y_pred_ext,~,yint]=predict(gprMdl1,x_pred_ext);

    y_sigma_vector_ext(:,n)=y_pred_ext;


    %外挿の線形補間
    x_exterp=linspace(sqrt(5),sqrt(100),50)';
    y_exterp(:,n)=sigmapc(4,n)+(sigmapc(5,n)-sigmapc(4,n))/(sqrt(10)-sqrt(5))*(x_exterp-sqrt(5));



    % 全部表示すると大変なので、PC1-3まで時間方向に表示する
    if(n<=3)
        figure;
        scatter(x_obs,y_obs_ext,70,'blue');
        hold on;
        plot(x_pred_ext,y_pred_ext,'black', 'LineWidth',1.5);
        patch([x_pred_ext;flipud(x_pred_ext)],[yint(:,1);flipud(yint(:,2))],'k','FaceAlpha',0.1, 'Edgecolor','None');
        scatter(sqrt(100),sigmapc_cycle100(1,n),70,'black','filled');
        plot(x_exterp,y_exterp(:,n),'LineWidth',1.5);
        ylim([0 8])
    end

end





%% 


% 【内挿補間】----------------------------------------------
% 各サイクル数の重心点に対してGaussianProcessを適用する
%              ^^^^^^^

x_obs=[0;1;sqrt(2);sqrt(10)];

mod_masscenter=masscenter;
mod_masscenter(2,:)=masscenter(3,:);
mod_masscenter(3,:)=masscenter(2,:);
mod_masscenter(4,:)=masscenter(5,:);
mod_masscenter(5,:)=masscenter(4,:);


% 重心位置の各PC次元を時間方向に回帰する
y_pred_vector=zeros(40,N_COMP_DIM);

for n=1:N_COMP_DIM
    y_obs=mod_masscenter(:,n);
    y_obs(4)=[];

    gprMdl1=fitrgp(x_obs, y_obs);

    x_pred=linspace(0,4,40)';
    [y_pred,~,yint]=predict(gprMdl1,x_pred);

    y_pred_vector(:,n)=y_pred;


    %内挿の線形補間
    x_interp=linspace(sqrt(2),sqrt(10),50)';
    y_interp(:,n)=mod_masscenter(3,n)+(mod_masscenter(5,n)-mod_masscenter(3,n))/(sqrt(10)-sqrt(2))*(x_interp-sqrt(2));

    % 全部表示すると大変なので、PC1-3まで時間方向に表示する
    if(n<=3)
        figure;
        scatter(x_obs,y_obs,70,'blue');
        hold on;
        plot(x_pred,y_pred,'black', 'LineWidth',1.5);
        patch([x_pred;flipud(x_pred)],[yint(:,1);flipud(yint(:,2))],'k','FaceAlpha',0.1, 'Edgecolor','None');
        scatter(sqrt(5),mod_masscenter(4,n),70,'blue');
        plot(x_interp,y_interp(:,n),'LineWidth',1.5)
        ylim([-8 8])
    end

end
 


%% 


% 標準偏差の各PC次元を時間方向に回帰する
% ^^^^^^^^
y_sigma_vector=zeros(40,N_COMP_DIM);

for n=1:N_COMP_DIM
    y_obs=sigmapc(:,n);
    y_obs(4)=[];

    sigma0 = 1e-4;%0.2;
    kparams0 = [3.5e-1, 6.2e-1]; %[3.5, 6.2];
    %gprMdl1=fitrgp(x_obs, y_obs,'KernelFunction','squaredexponential',...
    %     'KernelParameters',kparams0,'Sigma',sigma0);
    gprMdl1=fitrgp(x_obs, y_obs);

    x_pred=linspace(0,4,40)';
    [y_pred,~,yint]=predict(gprMdl1,x_pred);

    y_sigma_vector(:,n)=y_pred;


    %内挿の線形補間
    x_interp=linspace(sqrt(2),sqrt(10),50)';
    y_sigma_interp(:,n)=sigmapc(3,n)+(sigmapc(5,n)-sigmapc(3,n))/(sqrt(10)-sqrt(2))*(x_interp-sqrt(2));

    % 全部表示すると大変なので、PC1-3まで時間方向に表示する
    if(n<=3)
        figure;
        scatter(x_obs,y_obs,70,'blue');
        hold on;
        plot(x_pred,y_pred,'black', 'LineWidth',1.5);
        patch([x_pred;flipud(x_pred)],[yint(:,1);flipud(yint(:,2))],'k','FaceAlpha',0.1, 'Edgecolor','None');
        scatter(sqrt(5),sigmapc(4,n),70,'blue');
        plot(x_interp,y_sigma_interp(:,n),'LineWidth',1.5)
        ylim([0 8])
    end

end




%% 

rng default;

%---------------------------------------------------------------------------
% 重心点と標準偏差の内挿補間（5th cycle）から、点を生成する
N_GEN_POINTS=350;
Interp_points_GPR=zeros(N_GEN_POINTS,N_COMP_DIM);
Interp_points_LR=zeros(N_GEN_POINTS,N_COMP_DIM);

temp_Interp_points_GPR=zeros(N_GEN_POINTS,N_COMP_DIM);
temp_Interp_points_LR=zeros(N_GEN_POINTS,N_COMP_DIM);

for m=1:N_GEN_POINTS
    for n=1:N_COMP_DIM
        temp_Interp_points_GPR(m,n)=y_pred_vector(30,n)+2*y_sigma_vector(30,n)*randn();
        temp_Interp_points_LR(m,n)=y_interp(30,n)+2*y_sigma_interp(30,n)*randn();
    end

end

%----------------------------------------------
% 最近接の実画像の点を探索し、その座標を採用する
%----------------------------------------------
% GPRに対して
for p=1:N_GEN_POINTS
    min_euclength=1.0e9;

    for m=1:Num_images
        diffvector=score2(m,1:30)-temp_Interp_points_GPR(p,1:30);
        euclength=norm(diffvector);
        
        if(euclength<min_euclength)
            Interp_points_GPR(p,:)=score2(m,:);
            min_euclength=euclength;
        end
    end
end

% LRに対して
for p=1:N_GEN_POINTS
    min_euclength=1.0e9;

    for m=1:Num_images
        diffvector=score2(m,1:30)-temp_Interp_points_LR(p,1:30);
        euclength=norm(diffvector);
        
        if(euclength<min_euclength)
            Interp_points_LR(p,:)=score2(m,:);
            min_euclength=euclength;
        end
    end
end





figure;
scatter3(outscore2(672*3+1:672*4,1),outscore2(672*3+1:672*4,2),outscore2(672*3+1:672*4,3),[],outscore2(672*3+1:672*4,251),'filled')
colormap("jet")
xlim([-10 10])
ylim([-10 10])
zlim([-10 10])
clim([1 5])

hold on
scatter3(Interp_points_GPR(:,1),Interp_points_GPR(:,2),Interp_points_GPR(:,3),50,[0.4 0.4 0.4],'filled')
scatter3(Interp_points_LR(:,1),Interp_points_LR(:,2),Interp_points_LR(:,3),50,[0.8 0.8 0.8],'filled')



%% 

%---------------------------------------------------------------------------
% 生成した点から画像を復元する
Gen_Recov_GPR=zeros(56,56,N_GEN_POINTS);
Gen_Recov_LR=zeros(56,56,N_GEN_POINTS);
Gen_test3_GPR=Interp_points_GPR()*coeff2'+mu;
Gen_test3_LR=Interp_points_LR()*coeff2'+mu;
 
for n=1:N_GEN_POINTS
    m=1;
    for i=1:56
        for j=1:56
            Gen_Recov_GPR(i,j,n)=Gen_test3_GPR(n,m);  %OneDim_Xtrain(n,m);
            Gen_Recov_LR(i,j,n)=Gen_test3_LR(n,m);  %OneDim_Xtrain(n,m);
            
            m=m+1;
        end
    end
end



% GPRによる予測画像出力
figure;
m=1;
for n=1:N_GEN_POINTS

    for mi=1:56
        for mj=1:56
            if(Gen_Recov_GPR(mi,mj,n)<=0.33)
                Gen_Recov_GPR(mi,mj,n)=0;
            elseif(Gen_Recov_GPR(mi,mj,n)<=0.76)
                Gen_Recov_GPR(mi,mj,n)=0.5;
            else
                Gen_Recov_GPR(mi,mj,n)=1.0;
            end
        end
    end


    %figure;
    if(mod(n,70)==0)
        subplot(1,5,m);
        fig=pcolor(Gen_Recov_GPR(:,:,n));
        set(fig, 'Edgecolor', 'none');
        %colorbar;
        %pbaspect([1 1 1])
        clim([0 1]);
        axis off;
        m=m+1;
    end

end


% LRによる予測画像出力
figure;
m=1;
for n=1:N_GEN_POINTS

    for mi=1:56
        for mj=1:56
            if(Gen_Recov_LR(mi,mj,n)<=0.33)
                Gen_Recov_LR(mi,mj,n)=0;
            elseif(Gen_Recov_LR(mi,mj,n)<=0.76)
                Gen_Recov_LR(mi,mj,n)=0.5;
            else
                Gen_Recov_LR(mi,mj,n)=1.0;
            end
        end
    end


    %figure;
    if(mod(n,70)==0)
        subplot(1,5,m);
        fig=pcolor(Gen_Recov_LR(:,:,n));
        set(fig, 'Edgecolor', 'none');
        %colorbar;
        %pbaspect([1 1 1])
        clim([0 1]);
        axis off;
        m=m+1;
    end

end


figure;
m=1;
for n=672*3+1:672*4
    if(mod(n,134)==0)
        subplot(1,5,m);
        fig=pcolor(XTrain(:,:,n));
        set(fig, 'Edgecolor', 'none');
        %colorbar;
        %pbaspect([1 1 1])
        clim([0 1]);
        axis off;
        m=m+1;
    end

end




%% 


%---------------------------------------------------------------------------
% 復元した画像を分析し、正解データと比較する

VolRatio=zeros(672,4,3);  %サイクル#、活物質体積分率、バインダ体積分率、空隙率


% 正解画像
m=1;
nn=1;
for n=672*3+1:672*4

    VolRatio(nn,1,m)=n;

    for mi=1:56

        for mj=1:56
            if(XTrain(mi,mj,n)>0.66)
                VolRatio(nn,2,m)=VolRatio(nn,2,m)+1;
            elseif(XTrain(mi,mj,n)>0.33)
                VolRatio(nn,3,m)=VolRatio(nn,3,m)+1;
            else
                VolRatio(nn,4,m)=VolRatio(nn,4,m)+1;
            end
        end
    end
    %fprintf('%d\n',n);
    nn=nn+1;
end

VolRatio(:,2,1)=VolRatio(:,2,1)/(56*56);
VolRatio(:,3,1)=VolRatio(:,3,1)/(56*56);
VolRatio(:,4,1)=VolRatio(:,4,1)/(56*56);



% ガウス過程回帰
m=2;
for n=1:350
    VolRatio(n,1,m)=n;

    for mi=1:56

        for mj=1:56
            if(Gen_Recov_GPR(mi,mj,n)<0.2)
                VolRatio(n,4,m)=VolRatio(n,4,m)+1;
            elseif(Gen_Recov_GPR(mi,mj,n)<0.55)
                VolRatio(n,3,m)=VolRatio(n,3,m)+1;
            else
                VolRatio(n,2,m)=VolRatio(n,2,m)+1;
            end
        end
    end
    %fprintf('%d\n',n);

end

VolRatio(1:350,2,2)=VolRatio(1:350,2,2)/(56*56);
VolRatio(1:350,3,2)=VolRatio(1:350,3,2)/(56*56);
VolRatio(1:350,4,2)=VolRatio(1:350,4,2)/(56*56);



% 線形回帰
m=3;
for n=1:350
    VolRatio(n,1,m)=n;

    for mi=1:56

        for mj=1:56
            if(Gen_Recov_LR(mi,mj,n)<0.2)
                VolRatio(n,4,m)=VolRatio(n,4,m)+1;
            elseif(Gen_Recov_LR(mi,mj,n)<0.55)
                VolRatio(n,3,m)=VolRatio(n,3,m)+1;
            else
                VolRatio(n,2,m)=VolRatio(n,2,m)+1;
            end
        end
    end
    %fprintf('%d\n',n);

end

VolRatio(:,2,3)=VolRatio(:,2,3)/(56*56);
VolRatio(:,3,3)=VolRatio(:,3,3)/(56*56);
VolRatio(:,4,3)=VolRatio(:,4,3)/(56*56);



%% 

randnum=0.25*randn(672,1);
PointSize=10;

figure;
scatter(randnum(:,1),VolRatio(:,2,1),PointSize,[0.8500 0.3250 0.0980],'filled')
 hold on
scatter(randnum(1:350,1)+1.5,VolRatio(1:350,2,2),PointSize,[0.4 0.4 0.4],'filled')
scatter(randnum(1:350,1)+3,VolRatio(1:350,2,3),PointSize,[0.8 0.8 0.8],'filled')
%plot(VolRatio(:,3))
%plot(VolRatio(:,4))
ylim([0 1])

scatter(randnum(:,1)+7,VolRatio(:,3,1),PointSize,[0.8500 0.3250 0.0980],'filled')
scatter(randnum(1:350,1)+8.5,VolRatio(1:350,3,2),PointSize,[0.4 0.4 0.4],'filled')
scatter(randnum(1:350,1)+10,VolRatio(1:350,3,3),PointSize,[0.8 0.8 0.8],'filled')

scatter(randnum(:,1)+14,VolRatio(:,4,1),PointSize,[0.8500 0.3250 0.0980],'filled')
scatter(randnum(1:350,1)+15.5,VolRatio(1:350,4,2),PointSize,[0.4 0.4 0.4],'filled')
scatter(randnum(1:350,1)+17,VolRatio(1:350,4,3),PointSize,[0.8 0.8 0.8],'filled')




%% 

% 生成画像と正解画像のヒストグラム比較 -------------------------------------
MAX_R=10;    %探索半径
map_psd=zeros(56,56);


% 正解画像 -----------------
kk=1;
fprintf('Images for training... -----------\n');
for cn=1:500
    map=XTrain(:,:,672*3+cn);
    calcpsd02;

    if(mod(cn,10)==0)
        fprintf('%f pct completed...\n',cn/200*100);
    end

end

figure;
edges=1:12;
histogram(array_map_psd(:,2),edges, 'Normalization', 'probability','FaceColor',[0.8500 0.3250 0.0980]);
%hold on;
ylim([0 0.5])



% 生成画像(GPR) -----------------
kk=1;
fprintf('Images for Predicted by GPR... -----------\n');
for cn=1:350
    map=Gen_Recov_GPR(:,:,cn);
    calcpsd02;

    if(mod(cn,10)==0)
        fprintf('%f pct completed...\n',cn/350*100);
    end

end

figure;
fprintf('\n');
fprintf('Calculate Histograms...\n');

edges=1:12;
histogram(array_map_psd(:,2),edges, 'Normalization', 'probability','FaceColor',[0.5 0.5 0.5]);
ylim([0 0.5])



% 生成画像(LR) -----------------
kk=1;
fprintf('Images for Predicted by LR... -----------\n');
for cn=1:350
    map=Gen_Recov_LR(:,:,cn);
    calcpsd02;

    if(mod(cn,10)==0)
        fprintf('%f pct completed...\n',cn/350*100);
    end

end

figure;
fprintf('\n');
fprintf('Calculate Histograms...\n');

edges=1:12;
histogram(array_map_psd(:,2),edges, 'Normalization', 'probability','FaceColor',[0.1 0.1 0.1]);
ylim([0 0.5])

% figure;
% fig=pcolor(map_psd);
% set(fig, 'Edgecolor', 'none');

%% 


% 正解画像 サイクル1-10のPSD評価 -------------------------------------------


fprintf('Images for Predicted by GPR... -----------\n');

PSize=readmatrix('ParticleSize.csv');

for dn=1:5

    figure;
    
    edges=1:12:101;
    %histogram(array_map_psd(:,2),edges, 'Normalization', 'probability','FaceColor',[0.5 0.5 0.5]);
    histogram(PSize(2:PSize(1,dn),dn),edges, 'Normalization', 'probability');
    ylim([0 0.4])
    hold on

end





%% 

% 体積分率評価 ------------------------------------------------------------
VolRatioTot=zeros(Num_images,2);  %サイクル#、活物質体積分率

for n=1:Num_images

    cnum=floor(n/672)+1;
    VolRatioTot(n,1)=cnum;

    for mi=1:56

        for mj=1:56
            if(XTrain(mi,mj,n)>0.66)
                VolRatioTot(n,2)=VolRatioTot(n,2)+1;
            end
        end
    end
end

VolRatioTot(:,2)=VolRatioTot(:,2)/(56*56);


figure;
scatter(VolRatioTot(:,1),VolRatioTot(:,2));


%% 



% Single Particle Modelによる特性計算 -------------------------------------

FAR=96485;              % Faraday const. [s*A/mol]
Voltage=zeros(450,2,Num_images);   % 10sで1点
Conc=zeros(450,2,Num_images);
CapTot=zeros(Num_images,3);   % 上限電圧に達する時間 [s]
R_const=8.314;
Tenv=298;
i0=1.0;

Cmax=3.125e5;           % 最大Li濃度 [mol/m^3]
C0=3.0e5;               % 初期Li濃度 [mol/m^3]
I_in=10;                % 印加電流 [A/m^2]
V_cut=0.6;
L_ratio=1.0;



% 実測画像に基づく特性SIM --------------------------------
figure;
for n=1:Num_images

    S_ratio=3.0e5;

    if(n<=672*1)
        AM_ratio=VolRatioTot(n,2);
    elseif(n<=672*2)
        AM_ratio=VolRatioTot(n,2)*(1-0.133);
    elseif(n<=672*3)
        AM_ratio=VolRatioTot(n,2)*(1-0.182);
    elseif(n<=672*4)
        AM_ratio=VolRatioTot(n,2)*(1-0.289);
    elseif(n<=672*5)
        AM_ratio=VolRatioTot(n,2)*(1-0.351);
    end




    % Loop -----------------------
    temp_Conc=C0;
    p=1;
    UpFlg=0;
    for t=0:4500
        temp_Conc=temp_Conc-(I_in/FAR)*S_ratio/AM_ratio;

        if(mod(t,10)==0)
            Conc(p,1,n)=t;
            Conc(p,2,n)=temp_Conc;
            Voltage(p,1,n)=t;
            Voltage(p,2,n)=calc_ocp(temp_Conc/Cmax)+(R_const*Tenv)*((I_in/(S_ratio*L_ratio))/(2*i0));

            if(Voltage(p,2,n)>V_cut && UpFlg==0)
                if(n<672*1)
                    CapTot(n,1)=1+0.1*randn();
                    CapTot(n,3)=1;
                elseif(n<672*2)
                    CapTot(n,1)=2+0.1*randn();
                    CapTot(n,3)=2;
                elseif(n<672*3)
                    CapTot(n,1)=3+0.1*randn();
                    CapTot(n,3)=3;
                elseif(n<672*4)
                    CapTot(n,1)=5+0.1*randn();
                    CapTot(n,3)=4;
                elseif(n<672*5)
                    CapTot(n,1)=10+0.1*randn();
                    CapTot(n,3)=5;
                end
                CapTot(n,2)=t;
                UpFlg=1;
            end

            p=p+1;
        end

    end


    if(mod(n,10)==0)
        if(n<=672)
            plot(Voltage(:,1,n),Voltage(:,2,n),'color',[0 0.4470 0.7410]);
            hold on;
        elseif(n<=672*2)
            plot(Voltage(:,1,n),Voltage(:,2,n),'color',[0.3010 0.7450 0.9330]);
            hold on;
        elseif(n<=672*3)
            plot(Voltage(:,1,n),Voltage(:,2,n),'color',[0.9290 0.6940 0.1250]);
            hold on;
        elseif(n<=672*4)
            plot(Voltage(:,1,n),Voltage(:,2,n),'color',[0.8500 0.3250 0.0980]);
            hold on;
        elseif(n<=672*5)
            plot(Voltage(:,1,n),Voltage(:,2,n),'color',[0.6350 0.0780 0.1840]);
            hold on;
        end

    end

    if(mod(n,100)==0)
        fprintf("%f pct completed...\n", n/Num_images*100);
    end
    
end

ylim([0 0.6])


figure;
scatter(CapTot(:,1),CapTot(:,2)/3600,[],CapTot(:,3),'filled')
colormap("jet")
xlim([0.1 12])
ylim([0 1.5])




%% 

% 生成画像に対するSPモデル評価

Gen_Voltage=zeros(450,2,N_GEN_POINTS);   % 10sで1点
Gen_Conc=zeros(450,2,N_GEN_POINTS);
Gen_CapTot=zeros(N_GEN_POINTS,3,2);   % 上限電圧に達する時間 [s]


figure;


% Gaussian Process
for n=1:N_GEN_POINTS

    AM_ratio=VolRatio(n,2,2);    % VolRatio(n,2,2)の一番右の2がGPR
    S_ratio=1.0e6;


    % Loop -----------------------
    temp_Conc=C0;
    p=1;
    UpFlg=0;              % UpFlg=1: 上限電圧に達した

    for t=0:4500
        temp_Conc=temp_Conc-(I_in/FAR)*S_ratio*AM_ratio;

        if(mod(t,10)==0)
            Gen_Conc(p,1,n)=t;
            Gen_Conc(p,2,n)=temp_Conc;
            Gen_Voltage(p,1,n)=t;
            Gen_Voltage(p,2,n)=calc_ocp(temp_Conc/Cmax);

            if(Gen_Voltage(p,2,n)>V_cut && UpFlg==0)
                Gen_CapTot(n,1,1)=2+0.1*randn();
                Gen_CapTot(n,3,1)=1;
                Gen_CapTot(n,2,1)=t;
                UpFlg=1;
            end

            p=p+1;
        end
    end


    plot(Gen_Voltage(:,1,n),Gen_Voltage(:,2,n),'color',[0.5 0.5 0.5]);
    hold on;
  
    
end



% Linear Regression
for n=1:N_GEN_POINTS


    AM_ratio=VolRatio(n,2,3);    % VolRatio(n,2,2)の一番右の3がLR
    S_ratio=1.0e6;


    % Loop -----------------------
    temp_Conc=C0;
    p=1;
    UpFlg=0;              % UpFlg=1: 上限電圧に達した

    for t=0:4500
        temp_Conc=temp_Conc-(I_in/FAR)*S_ratio*AM_ratio;

        if(mod(t,10)==0)
            Gen_Conc(p,1,n)=t;
            Gen_Conc(p,2,n)=temp_Conc;
            Gen_Voltage(p,1,n)=t;
            Gen_Voltage(p,2,n)=calc_ocp(temp_Conc/Cmax);

            if(Gen_Voltage(p,2,n)>V_cut && UpFlg==0)
                Gen_CapTot(n,1,2)=3+0.1*randn();
                Gen_CapTot(n,3,2)=1;
                Gen_CapTot(n,2,2)=t;
                UpFlg=1;
            end


            p=p+1;
        end
    end


    plot(Gen_Voltage(:,1,n),Gen_Voltage(:,2,n),'color',[0.3 0.3 0.3]);
    hold on;
  
    
end

for n=672*3+1:672*4
    plot(Voltage(:,1,n),Voltage(:,2,n),'color',[0.8500 0.3250 0.0980]);
    hold on;
end
ylim([0 0.6])



figure;
scatter(CapTot(672*3+1:672*4-1,1)-4,CapTot(672*3+1:672*4-1,2)/3600,[],[0.8500 0.3250 0.0980],'filled')
xlim([0.1 4])
ylim([0 1.5])

hold on;
scatter(Gen_CapTot(:,1,1),Gen_CapTot(:,2,1)/3600,[],[0.5 0.5 0.5],'filled')
scatter(Gen_CapTot(:,1,2),Gen_CapTot(:,2,2)/3600,[],[0.8 0.8 0.8],'filled')





%% 

% 各サイクル（1,2,3,4,5）の重心点の最近接点
Near_masscenter=zeros(5,N_COMP_DIM+1);

min_euclength=zeros(5,2);       % (重心との最小ユークリッド距離, 番号)
min_euclength(:,1)=1.0e9;

for p=1:5
    for n=Num_images/5*(p-1)+1:Num_images/5*p
        diffvector=score2(n,1:3)-masscenter(p,1:3);
        euclength=norm(diffvector);
        if(euclength<min_euclength(p,1))
            min_euclength(p,1)=euclength;
            min_euclength(p,2)=n;
        end
    end
   
end



figure;
scatter3(masscenter(:,1),masscenter(:,2),masscenter(:,3),[],masscenter(:,N_COMP_DIM+1),'filled');
hold on
for q=1:5
    scatter3(score2(min_euclength(q,2),1),score2(min_euclength(q,2),2),score2(min_euclength(q,2),3),[],1,'filled');
end
xlim([-10 10])
ylim([-10 10])
zlim([-10 10])



% 生成した点から画像を復元する
Gen_Recov_XTrain=zeros(56,56,Num_images);
Gen_test2=score2()*coeff2'+mu;
 
for n=1:Num_images
    m=1;
    for i=1:56
        for j=1:56
            Gen_Recov_XTrain(i,j,n)=Gen_test2(n,m);  %OneDim_Xtrain(n,m);
            m=m+1;
        end
    end
end


Gen_N_Recov_Image=min_euclength(:,2)';          %復元する画像番号

figure;
for n=1:length(Gen_N_Recov_Image)

    for mi=1:56
        for mj=1:56
            if(Gen_Recov_XTrain(mi,mj,Gen_N_Recov_Image(n))<=0.33)
                Gen_Recov_XTrain(mi,mj,Gen_N_Recov_Image(n))=0;
            elseif(Gen_Recov_XTrain(mi,mj,Gen_N_Recov_Image(n))<=0.66)
                Gen_Recov_XTrain(mi,mj,Gen_N_Recov_Image(n))=0.5;
            else
                Gen_Recov_XTrain(mi,mj,Gen_N_Recov_Image(n))=1.0;
            end
        end
    end


    %figure;
    subplot(1,5,n);
    fig=pcolor(Gen_Recov_XTrain(:,:,Gen_N_Recov_Image(n)));
    set(fig, 'Edgecolor', 'none');
    %colorbar;
    %pbaspect([1 1 1])
    clim([0 1]);
    axis off;
    

end




%% 

% 





%% 

% PC空間の2点間を線形補完する
% サイクル3と4の間をN_IP 点で補間する
N_IP=10;
Gen_score2=zeros(N_IP,N_COMP_DIM);
Gen_sigma=0.25;

rng default;


% 1点目
p=3;  %サイクル3
for m=1:N_COMP_DIM
    Gen_score2(1,m)=score2(min_euclength(p,2),m);
end

% N_IP点目
p=4;  %サイクル4
for m=1:N_COMP_DIM
    Gen_score2(N_IP,m)=score2(min_euclength(p,2),m);
end

% 2,3,4,...N_IP-1 点目
for q=2:N_IP-1
    add_rand=Gen_sigma*randn();
    for m=1:N_COMP_DIM
        Gen_score2(q,m)=(Gen_score2(N_IP,m)-Gen_score2(1,m))/N_IP*q+Gen_score2(1,m)+add_rand;
    end
end

out_add_array=1:N_IP;
out_Gen_score2=horzcat(Gen_score2,out_add_array');


figure;
scatter3(masscenter(3:4,1),masscenter(3:4,2),masscenter(3:4,3),[],masscenter(3:4,N_COMP_DIM+1),'filled');
xlim([-10 10])
ylim([-10 10])
zlim([-10 10])

figure;
scatter3(out_Gen_score2(:,1),out_Gen_score2(:,2),out_Gen_score2(:,3),[],out_Gen_score2(:,251),'filled')
xlim([-10 10])
ylim([-10 10])
zlim([-10 10])



%% 

% 生成した点から画像を復元する

Gen_Recov_XTrain=zeros(56,56,N_IP);
Gen_test2=Gen_score2()*coeff2'+mu;
 
for n=1:N_IP
    m=1;
    for i=1:56
        for j=1:56
            Gen_Recov_XTrain(i,j,n)=Gen_test2(n,m);  %OneDim_Xtrain(n,m);
            m=m+1;
        end
    end
end



figure;
for n=1:N_IP

    for mi=1:56
        for mj=1:56
            if(Gen_Recov_XTrain(mi,mj,n)<=0.33)
                Gen_Recov_XTrain(mi,mj,n)=0;
            elseif(Gen_Recov_XTrain(mi,mj,n)<=0.66)
                Gen_Recov_XTrain(mi,mj,n)=0.5;
            else
                Gen_Recov_XTrain(mi,mj,n)=1.0;
            end
        end
    end


    %figure;
    subplot(1,N_IP,n);
    fig=pcolor(Gen_Recov_XTrain(:,:,n));
    set(fig, 'Edgecolor', 'none');
    %colorbar;
    %pbaspect([1 1 1])
    clim([0 1]);
    axis off;
    

end





%% 

% 生成画像の分析-----------------------------------------------------------

VolRatio=zeros(N_IP,4);  %サイクル#、活物質体積分率、バインダ体積分率、空隙率


for n=1:N_IP
    VolRatio(n,1)=n;

    for mi=1:56

        for mj=1:56
            if(Gen_Recov_XTrain(mi,mj,n)<0.1)
                VolRatio(n,4)=VolRatio(n,4)+1;
            elseif(Gen_Recov_XTrain(mi,mj,n)<0.55)
                VolRatio(n,3)=VolRatio(n,3)+1;
            else
                VolRatio(n,2)=VolRatio(n,2)+1;
            end
        end
    end


end


figure;
plot(VolRatio(:,2))
hold on
plot(VolRatio(:,3))
plot(VolRatio(:,4))






%% 
