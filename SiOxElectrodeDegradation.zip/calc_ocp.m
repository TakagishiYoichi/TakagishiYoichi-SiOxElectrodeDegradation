function Uocp=calc_ocp(soc)

    if(soc>0)
        Uocp=-4.76*(soc^6)+9.34*(soc^5)-1.8*(soc^4)-7.13*(soc^3)+5.8*(soc^2)-1.94*soc+0.62;
    else
        Uocp=0.62;
    end

end