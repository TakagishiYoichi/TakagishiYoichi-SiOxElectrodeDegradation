%----------------------------------------------------------------------
% Calc Pore Size Distribution
%----------------------------------------------------------------------



%Load image----------------------------------------------------------
%map=imread('Half_Inv_SIM_binary.png');

%map=double(map);
NXY=size(map);
NX=NXY(1);
NY=NXY(2);
mapbn=zeros(length(map));
for i=1:NX
    for j=1:NY
        if(map(i,j)<0.5)   % �󌄂�ΏۂƂ���
        %if(map(i,j)>0.85)    % ��������ΏۂƂ���
            mapbn(i,j)=1;
        end
    end
end


% 0: electrolyte, 1:Carbon atom



% PSD�}�b�v�쐬 ---------------------------------------------------------
for k=1:MAX_R
    
    % ���E�㉺�[�������ăX�L��������
    for i=1+k:NX-k
        for j=1+k:NY-k

            % ����_�̎��́i���ar���j�Ɍő������邩
            psd_flg=0;
            if(mapbn(i,j)==0)
                for m=i-k:i+k
                    for n=j-k:j+k
                        if(mapbn(m,n)>0 && m~=i && n~=j)
                            psd_flg=1;
                        end
                    end
                end
                
                % �ő����Ȃ���΁A���݂̔��a�̒lr����
                if(psd_flg==0)
                    for m=i-k:i+k
                        for n=j-k:j+k
                            if(mapbn(m,n)==0  && m~=i && n~=j)
                                map_psd(m,n)=k;
                            end
                        end
                    end
                end
                
            end
            
        end
    end
end


for i=1:NX
    for j=1:NY
        if(mapbn(i,j)==0)
            %�׍E"���a"
            array_map_psd(kk,1)=kk;
            array_map_psd(kk,2)=map_psd(i,j)+1;
            kk=kk+1;
        end
    end
end


